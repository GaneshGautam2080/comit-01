package com.comit.course._20_final_project;

class customer {

	int clntid;
	String name;
	String add;
	String phn;
		
	customer(){
	}  		
		 
	customer(int clntid, String name, String add,  String phn) {
				
				this.clntid = clntid;
				this.name = name;
				this.add = add;
				this.phn = phn;
				
	}
}

