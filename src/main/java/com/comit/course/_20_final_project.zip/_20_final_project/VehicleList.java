package com.comit.course._20_final_project;

class VehicleList {

	int carid;
	String made;
	String model;
	int year;
	String color;
	int seat;
	int milege;
		
	VehicleList(){
		
	}  		
		 
	VehicleList(int carid, String made, String model,  int year, String color, int seat, int milege) {
				super();
				this.carid = carid;
				this.made = made;
				this.model = model;
				this.year = year;
				this.color = color;
				this.seat = seat;
				this.milege = milege;

	}
	}


